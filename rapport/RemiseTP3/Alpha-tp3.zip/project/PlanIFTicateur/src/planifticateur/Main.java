
package planifticateur;

//Classe qui start le programme
public class Main {

    public static void main(String[] args) {
        planifticateur.gui.MainWindow mainWindow = new planifticateur.gui.MainWindow();
        mainWindow.setVisible(true);
    }
    
}
