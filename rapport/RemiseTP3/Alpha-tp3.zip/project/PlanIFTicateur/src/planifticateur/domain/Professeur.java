
package planifticateur.domain;


public class Professeur {
    String identifiant; //on n'a pas cette information
    String initiales;
    String bureau;      //on n'a pas cette information
    
    public Professeur(String initiale){
        //Constructeur
        this.initiales = initiale;
    }
}
